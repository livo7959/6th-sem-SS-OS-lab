void main()
{
	float a123;
	char a;
	chat b123;
	char c;
	if (sum == 10)
		printf("pass");
	else
		printf("fail");
}

