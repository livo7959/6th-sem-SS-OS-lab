# Commands to execute this program 

```
$yacc pgm.y -d 
$lex pgm.l 
$gcc -g lex.yy.c pgm.tab.c 
```
